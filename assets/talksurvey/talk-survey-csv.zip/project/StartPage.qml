import QtQuick
import QtQuick.Controls.Material
import QtQuick.Layouts
import CyberTracker as C

// Generated talk survey for a single EarthRanger event type. A survey is a session: the observer speaks, each
// clip is transcribed, and the timeline turns the session into one sighting per observation, deleting the raw
// clips it used (their audio survives on the observations). Records are submitted to EarthRanger as events of
// this type when the user presses Submit, distinguished by the type field chosen when the package was created.
// A CSV package (custom.exportCsv) has no backend: Export writes the records to a zip of CSV files and their
// audio, to share by email, and removes them from the device.
// Roles come from form.project.providerParams.custom. Form.qml must not be edited.
C.ContentPage {
    id: page

    property var custom: form.project.providerParams.custom
    property bool exportCsv: page.custom.exportCsv === true
    property bool working: false

    header: C.PageHeader {
        text: form.project.title
        menuIcon: "qrc:/icons/settings.svg"
        menuVisible: true
        onMenuClicked: {
            form.pushPage(form.getPage("SettingsPage.qml"))
        }
    }

    footer: RowLayout {
        spacing: 0
        width: page.width

        C.FooterButton {
            text: qsTr("Submit")
            visible: !page.exportCsv
            enabled: listView.canSubmitData && !page.working
            icon.source: "qrc:/icons/upload_multiple.svg"
            onClicked: {
                if (App.transcribeQueue.working) {
                    showError(qsTr("Wait, transcription in progress"))
                    return
                }

                confirmSubmit.open()
            }
        }

        C.FooterButton {
            text: qsTr("Export")
            visible: page.exportCsv
            enabled: listView.count !== 0 && !page.working
            icon.source: "qrc:/icons/export.svg"
            onClicked: {
                if (App.transcribeQueue.working) {
                    showError(qsTr("Wait, transcription in progress"))
                    return
                }

                confirmExport.open()
            }
        }

        C.FooterButton {
            text: qsTr("Map")
            icon.source: "qrc:/icons/map_outline.svg"
            onClicked: form.pushPage("qrc:/MapsPage.qml")
        }

        C.FooterButton {
            text: qsTr("New survey")
            enabled: !page.working
            icon.source: "qrc:/icons/plus.svg"
            onClicked: newSurvey()
        }
    }

    // Watermark.
    C.SquareIcon {
        anchors.centerIn: parent
        source: form.project.icon !== "" ? App.projectManager.getFileUrl(form.project.uid, form.project.icon) : ""
        size: Math.min(parent.width, parent.height) / 2
        opacity: 0.15
        recolor: false
    }

    C.SightingsListView {
        id: listView
        anchors.fill: parent
        active: true
        showNoData: false
        showStatusIcon: true
        groupBy: 6 /*SightingListModel.GroupBy.SessionId*/
        showNullGroup: false
        filter.projectUid: form.project.uid
        filter.stateSpace: form.stateSpace

        // Nothing is edited here: the stop record carries the session track, so show it; every other record
        // is shown in the inspector.
        onClicked: function (sighting, index) {
            if (sighting.trackOnly) {
                return
            }

            if (sighting.trackFileName !== "") {
                showTrackFile(page, sighting.trackFileName, sighting.trackFileSummary)
                return
            }

            appPageStack.pushPageImmediate("qrc:/InspectorPage.qml", { inspectList: listView.model, initialIndex: index })
        }
    }

    // Turns each finished session's clips into observation sightings, then fills their fields from the text.
    C.Timeline {
        id: timeline
        commandStart: page.custom.commandStart
        commandStop: page.custom.commandStop
        commandError: page.custom.commandError
        audioFieldUid: page.custom.audioField
        locationFieldUid: page.custom.locationField
        transcribeFieldUid: page.custom.notesField
        sessionIdFieldUid: page.custom.sessionIdField
        fillFieldUids: page.custom.fillFields
        extraFieldValues: buildExtraFieldValues()
        deleteSources: true
    }

    Component.onCompleted: {
        if (!form.project.loggedIn) {
            form.triggerLogin()
            return
        }

        ensureReportedBy()
        processSessions()
    }

    // Login completes asynchronously, so ask for the reporter once it has.
    Connections {
        target: form
        function onLoggedInChanged(loggedIn) {
            if (loggedIn) {
                ensureReportedBy()
            }
        }
    }

    // The page stays on the stack across a survey, so re-check the queue when it becomes current again.
    StackView.onActivated: processSessions()

    Connections {
        target: App.transcribeQueue
        function onWorkingChanged() {
            page.working = App.transcribeQueue.hasWork()
        }
        function onWorkCompleted() {
            processSessions()
        }
    }

    C.ConfirmPopup {
        id: confirmSubmit
        icon: "qrc:/icons/upload_multiple.svg"
        text: qsTr("Submit data?")
        confirmDelay: false
        onConfirmed: form.submitData()
    }

    C.ConfirmPopup {
        id: confirmExport
        icon: "qrc:/icons/export.svg"
        text: qsTr("Export data?")
        subText: qsTr("The records are written to a file to share and removed from this device")
        confirmText: qsTr("Yes, export it")
        onConfirmed: {
            busyCover.doWork = exportData
            busyCover.start()
        }
    }

    // CSV package: the records go to a zip of CSV files and their audio clips, listed on the exports page to
    // share from. Exported records are removed from the device, as submitted ones are.
    function exportData() {
        // Columns: the fixed ones are capitalised, the timestamp is dropped in favour of the form's own time field,
        // and the location field is dropped since the coordinates repeat it.
        let fieldNames = { deviceId: "DeviceId", id: "Id", timestamp: "", latitude: "Latitude", longitude: "Longitude", altitude: "Altitude", accuracy: "Accuracy" }
        fieldNames[page.custom.locationField] = ""
        fieldNames[page.custom.audioField] = "Audio"
        fieldNames[page.custom.notesField] = "Transcribe"

        let result = form.exportToCSV(true, fieldNames, true, "TalkSurvey")
        if (result.success) {
            form.pushPage("qrc:/ExportsPage.qml", { projectUid: form.project.uid })
        } else if (result.expected) {
            showToast(result.errorString)
        } else {
            showError(result.errorString)
        }
    }

    // Some backends require a reporter: ask for one until it is set. It can be changed on the settings page.
    function ensureReportedBy() {
        let elementUid = page.custom.reportedByElement || ""
        if (elementUid !== "" && form.project.reportedBy === "" && form.getElement(elementUid).hasChildren) {
            form.pushPage("qrc:/ReportedByPage.qml", { elementUid: elementUid })
        }
    }

    // Process sessions whose clips are all transcribed. Submission is manual, from the Submit button.
    function processSessions() {
        timeline.processPendingSessions()
        page.working = App.transcribeQueue.hasWork()
    }

    function buildExtraFieldValues() {
        let values = Object.assign({}, page.custom.fixedValues || {})
        values[page.custom.typeField] = page.custom.typeValues.data
        return values
    }

    // Fix the values and variables the package was built with, e.g. an event type and the geometry it uses.
    function applyFixedValues() {
        let values = page.custom.fixedValues || {}
        for (let uid in values) {
            form.setFieldValue(uid, values[uid])
            form.setFieldState(uid, 4 /*FieldState::Constant*/)
        }

        let variables = page.custom.sightingVariables || {}
        for (let name in variables) {
            form.setSightingVariable(name, variables[name])
        }
    }

    function newSurvey() {
        form.newSessionId()
        form.newSighting()

        // Every record of the survey carries its session id; clips copy it from here.
        form.setFieldValue(page.custom.sessionIdField, form.sessionId)

        applyFixedValues()

        form.pushPage(form.getPage("SessionPage.qml"))
    }
}
