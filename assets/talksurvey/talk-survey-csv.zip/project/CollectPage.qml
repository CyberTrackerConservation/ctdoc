import QtQuick
import QtQuick.Controls.Material
import QtQuick.Layouts
import CyberTracker as C

// Generated talk survey: collection. Runs the voice recorder continuously; each utterance becomes a clip record
// with its audio, location and time, queued for transcription. The screen is a reminder of what can be said.
// Stop survey snaps the track onto the stop record and pends the session for the timeline on the start page.
C.ContentPage {
    id: page

    property var custom: form.project.providerParams.custom

    QtObject {
        id: internal

        property alias listening: recorder.listening
        property alias recording: recorder.recording
        property string headerText: ""

        Component.onCompleted: {
            let metadataFields = page.custom.metadataFields
            if (metadataFields.length > 0) {
                headerText = form.getFieldDisplayValue(form.rootRecordUid, metadataFields[metadataFields.length - 1])
            }
        }
    }

    // Deferred so it runs after the list has laid out and restored any saved position.
    Component.onCompleted: Qt.callLater(listView.positionViewAtBeginning)

    C.SightingListModel {
        id: sightingListModel
        projectUid: form.projectUid
        stateSpace: form.stateSpace
    }

    C.VoiceRecorder {
        id: recorder

        speed: 1

        onVoiceStarted: function (filePath) {
            form.snapCreateTime()
            form.setFieldValue(page.custom.locationField, App.lastLocation.toMap)
        }

        onVoiceCompleted: function (filePath, duration, deleted) {
            if (deleted === true) {
                return
            }

            saveClip(filePath, duration)
        }

        Component.onCompleted: {
            recorder.start()
        }
    }

    // Header: home, track state, map, the session title, and Stop survey.
    header: Rectangle {
        id: h
        width: page.width

        property string textColor: Utils.lightness(Material.primary) < 130 ? "white" : "black"
        color: Material.primary
        height: Math.max(toolbarInternal.implicitHeight, titleRow.implicitHeight) + App.scaleByFontSize(4)

        ToolBar {
            id: toolbarInternal
            visible: false
        }

        RowLayout {
            width: parent.width
            spacing: 0

            RowLayout {
                Layout.preferredWidth: C.Style.toolButtonSize * 4
                Layout.maximumWidth: C.Style.toolButtonSize * 4
                Layout.alignment: Qt.AlignVCenter
                Layout.fillHeight: true
                spacing: 0

                ToolButton {
                    icon.source: C.Style.homeIconSource
                    icon.width: C.Style.toolButtonSize
                    icon.height: C.Style.toolButtonSize
                    icon.color: h.textColor
                    // Leave the project with this page on the saved stack: reopening returns here, mid-session.
                    onClicked: {
                        recorder.flush()
                        App.popPageStack()
                    }
                }

                ToolButton {
                    icon.source: App.locationLogger.stateIcon
                    icon.width: C.Style.toolButtonSize
                    icon.height: C.Style.toolButtonSize
                    icon.color: h.textColor
                    onClicked: App.showToast(form.trackStreamer.rateFullText)
                }

                ToolButton {
                    icon.source: "qrc:/icons/map_outline.svg"
                    icon.width: C.Style.toolButtonSize
                    icon.height: C.Style.toolButtonSize
                    icon.color: h.textColor
                    onClicked: form.pushPage("qrc:/MapsPage.qml")
                }
            }

            Label {
                id: titleRow
                Layout.alignment: Qt.AlignVCenter | Qt.AlignHCenter
                Layout.fillWidth: true
                font.pixelSize: App.settings.font20
                horizontalAlignment: Qt.AlignHCenter
                clip: true
                color: h.textColor
                text: internal.headerText !== "" ? internal.headerText : form.project.title
            }

            RowLayout {
                Layout.preferredWidth: C.Style.toolButtonSize * 4
                Layout.maximumWidth: C.Style.toolButtonSize * 4
                Layout.alignment: Qt.AlignVCenter
                Layout.fillHeight: true
                spacing: 0

                RoundButton {
                    Layout.alignment: Qt.AlignVCenter
                    Layout.fillWidth: true
                    text: qsTr("Stop survey")
                    font.pixelSize: App.settings.font12
                    radius: App.scaleByFontSize(4)
                    onClicked: stopSurvey()
                }
            }
        }
    }

    // Footer: recorder state and the clip count.
    footer: ColumnLayout {
        spacing: 0
        width: page.width

        C.HorizontalDivider { Layout.fillWidth: true; height: App.scaleByFontSize(2) }

        Pane {
            Layout.fillWidth: true
            contentItem: RowLayout {
                width: parent.width

                C.SquareIcon {
                    id: blinker
                    source: internal.recording ? "qrc:/icons/account_voice.svg" : "qrc:/icons/microphone.svg"
                    color: internal.recording ? "red" : (internal.listening ? "blue" : "#808080")

                    Timer {
                        running: true
                        repeat: true
                        interval: 1000
                        onTriggered: blinker.opacity = blinker.opacity === 0.0 ? 1.0 : 0.0
                    }
                }

                Label {
                    font.pixelSize: App.settings.font14
                    font.family: "monospace"
                    text: recorder.stateText + (recorder.recording ? " · " + recorder.durationText : "")
                }

                Item { Layout.fillWidth: true }

                Label {
                    font.pixelSize: App.settings.font14
                    font.family: "monospace"
                    text: qsTr("Recordings") + " · " + sightingListModel.count
                }
            }
        }
    }

    // The prompt sheet: every spoken field and the values it accepts.
    C.ListViewV {
        id: listView
        anchors.fill: parent
        spacing: 0

        model: C.FieldListProxyModel {
            recordUid: form.rootRecordUid
            filterFieldUids: page.custom.fillFields
        }

        header: ItemDelegate {
            width: parent.width
            contentItem: ColumnLayout {
                width: parent.width

                Label {
                    Layout.fillWidth: true
                    horizontalAlignment: Qt.AlignHCenter
                    font.pixelSize: App.settings.font14
                    font.bold: true
                    wrapMode: Label.WordWrap
                    text: qsTr("Say '%1', the fields below, then '%2'").arg(page.custom.commandStart).arg(page.custom.commandStop)
                }

                Label {
                    Layout.fillWidth: true
                    horizontalAlignment: Qt.AlignHCenter
                    font.pixelSize: App.settings.font14
                    font.bold: true
                    wrapMode: Label.WordWrap
                    text: qsTr("Say '%1', the fields, then '%2' to correct the previous observation").arg(page.custom.commandError).arg(page.custom.commandStop)
                }
            }

            C.HorizontalDivider { height: App.scaleByFontSize(2) }
        }

        delegate: ItemDelegate {
            width: listView.width
            contentItem: RowLayout {
                Item { height: C.Style.minRowHeight }

                Column {
                    Layout.fillWidth: true
                    spacing: App.scaleByFontSize(5)
                    height: listTitle.implicitHeight + listValue.implicitHeight

                    C.FieldName {
                        id: listTitle
                        recordUid: form.rootRecordUid
                        fieldUid: model.fieldUid
                        width: parent.width
                        font.pixelSize: App.settings.font14
                        font.bold: true
                    }

                    Label {
                        id: listValue
                        width: parent.width
                        wrapMode: Label.Wrap
                        visible: text !== ""
                        font.pixelSize: App.settings.font14
                        text: acceptedValues(model.fieldUid)
                    }
                }

                C.SquareIcon {
                    source: form.getFieldIcon(model.fieldUid)
                    size: C.Style.minRowHeight
                    visible: source !== ""
                }
            }

            C.HorizontalDivider {}
        }
    }

    function acceptedValues(fieldUid) {
        let field = form.getField(fieldUid)
        let listElementUid = field.listElementUid
        switch (form.getFieldType(fieldUid)) {
        case "NumberField":
            return qsTr("A number")

        case "CheckField":
            return listElementUid !== "" ? listItems(listElementUid) : qsTr("Yes or no")

        case "StringField":
            return listElementUid !== "" ? listItems(listElementUid) : qsTr("Text")
        }

        return ""
    }

    function listItems(elementUid) {
        let elements = form.getElement(elementUid).elements
        let result = ""
        for (let i = 0; i < elements.length; i++) {
            if (elements[i].other) {
                continue
            }

            if (result !== "") {
                result += ", "
            }

            result += form.getElementName(elements[i].uid)
        }

        return result
    }

    // A clip record: type voice, the audio (uploaded as an event file), the location snapped when speech
    // started, and a transcription request whose transcript lands in the notes field.
    function saveClip(audioFilePath, duration) {
        let recordUid = form.rootRecordUid
        let mediaFilename = App.moveToMedia(audioFilePath)

        form.setFieldValue(recordUid, page.custom.typeField, page.custom.typeValues.voice)
        form.setFieldValue(recordUid, page.custom.audioField, ({ filename: mediaFilename, duration: duration, timestamp: form.sighting.createTime }))

        let speechPrompt = page.custom.commandStart + " " + page.custom.commandStop + " " + page.custom.commandError + " " +
                           form.buildSpeechPrompt(recordUid, page.custom.fillFields)
        form.requestTranscribe(mediaFilename, speechPrompt)

        form.saveSighting()
        form.markSightingCompleted()
        form.markSightingReadonly()

        newClip()
    }

    // Next clip copies the session values; clear what belongs to the previous record.
    function newClip() {
        form.newSighting(true)
        form.resetFieldValue(page.custom.typeField)
        form.resetFieldValue(page.custom.audioField)
        form.resetFieldValue(page.custom.notesField)
        form.resetFieldValue(page.custom.locationField)
        form.saveState()
    }

    // The stop record carries the session track, uploaded as an event file.
    function stopSurvey() {
        recorder.flush()

        let recordUid = form.rootRecordUid
        let location = App.lastLocation.toMap

        form.pushTrackLocation(location)
        form.snapTrack()
        form.project.locationStreamingEnabled = false

        form.snapCreateTime()
        form.setFieldValue(recordUid, page.custom.locationField, location)
        form.setFieldValue(recordUid, page.custom.typeField, page.custom.typeValues.stop)
        form.saveSighting()
        form.markSightingCompleted()
        form.markSightingReadonly()

        // Pend this session for the timeline.
        form.appendPendingSessionId(form.sessionId)

        form.newSighting()
        form.popPagesToStart()
    }
}
