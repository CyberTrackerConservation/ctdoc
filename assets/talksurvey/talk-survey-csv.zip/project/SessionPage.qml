import QtQuick
import QtQuick.Controls.Material
import QtQuick.Layouts
import CyberTracker as C

// Generated talk survey: session setup. Edits the start location and the fields chosen as session fields,
// validates the required ones, starts track logging from that location, writes the session start record, then
// moves to the collect page. Every later clip in the session copies these values.
C.ContentPage {
    id: page

    property var custom: form.project.providerParams.custom

    header: C.PageHeader {
        text: qsTr("New survey")
    }

    footer: RowLayout {
        spacing: 0
        width: page.width

        C.FooterButton {
            text: qsTr("Start survey")
            icon.source: "qrc:/icons/play.svg"
            onClicked: startSurvey()
        }
    }

    C.ListViewV {
        id: listView
        anchors.fill: parent
        spacing: 0

        property bool highlightInvalid: false

        model: C.FieldListProxyModel {
            id: fieldListModel
            recordUid: form.rootRecordUid
            filterFieldUids: [page.custom.locationField].concat(page.custom.metadataFields)
        }

        delegate: C.FieldEditorDelegate {
            recordUid: form.rootRecordUid
            fieldUid: model.fieldUid
            highlightInvalid: listView.highlightInvalid
            C.HorizontalDivider {}
        }
    }

    function startSurvey() {
        // Validate the session fields.
        for (let i = 0; i < fieldListModel.count; i++) {
            if (!form.getFieldValueValid(form.rootRecordUid, fieldListModel.get(i).fieldUid)) {
                listView.highlightInvalid = true
                return
            }
        }

        // Start the track from the session location.
        form.project.locationStreamingEnabled = true
        form.pushTrackLocation(form.getFieldValue(form.rootRecordUid, page.custom.locationField))

        // The session start record.
        form.snapCreateTime()
        form.setFieldValue(page.custom.typeField, page.custom.typeValues.start)
        form.saveSighting()
        form.markSightingCompleted()
        form.markSightingReadonly()

        // Clips copy the session values.
        form.newSighting(true)
        form.replaceLastPage(form.getPage("CollectPage.qml"))
    }
}
