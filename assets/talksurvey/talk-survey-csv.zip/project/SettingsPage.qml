import QtQuick
import QtQuick.Controls.Material
import QtQuick.Layouts
import CyberTracker as C

// Settings for a generated EarthRanger package: system settings, package update, login and the reporter. A CSV
// package has no login; it lists its exported files instead.
C.ContentPage {
    id: page

    property var custom: form.project.providerParams.custom
    property bool exportCsv: page.custom.exportCsv === true

    header: C.PageHeader {
        text: qsTr("Settings")
    }

    Flickable {
        anchors.fill: parent
        ScrollBar.vertical: ScrollBar { interactive: false }
        contentWidth: parent.width
        contentHeight: column.height

        ColumnLayout {
            id: column
            width: parent.width
            spacing: 0

            ItemDelegate {
                Layout.fillWidth: true
                Layout.minimumHeight: C.Style.minRowHeight
                contentItem: RowLayout {
                    Label {
                        Layout.fillWidth: true
                        text: qsTr("System settings")
                        font.pixelSize: App.settings.font14
                        font.capitalization: Font.MixedCase
                        font.bold: false
                        wrapMode: Label.WordWrap
                    }

                    C.SquareIcon {
                        source: "qrc:/icons/cogs.svg"
                        opacity: 0.5
                    }

                    C.ChevronRight {}
                }

                onClicked: {
                    form.pushPage("qrc:/SettingsPage.qml")
                }

                C.HorizontalDivider {}
            }

            ItemDelegate {
                Layout.fillWidth: true
                Layout.minimumHeight: C.Style.minRowHeight
                visible: App.projectManager.canUpdate(form.project.uid)

                contentItem: RowLayout {
                    width: parent.width
                    height: parent.height

                    ColumnLayout {
                        Layout.fillWidth: true

                        Label {
                            Layout.fillWidth: true
                            font.pixelSize: App.settings.font14
                            text: qsTr("Last updated")
                            elide: Text.ElideRight
                            wrapMode: Label.WordWrap
                        }

                        Label {
                            Layout.fillWidth: true
                            font.pixelSize: App.settings.font12
                            opacity: 0.5
                            text: form.project.lastUpdate
                            elide: Text.ElideRight
                            wrapMode: Label.WordWrap
                            visible: text !== ""
                        }
                     }

                    Button {
                        text: qsTr("Update")
                        font.pixelSize: App.settings.font14
                        font.capitalization: Font.MixedCase
                        icon.source: "qrc:/icons/autorenew.svg"
                        Layout.alignment: Qt.AlignRight
                        enabled: form.project.loggedIn
                        onClicked: {
                            if (Utils.networkAvailable()) {
                                busyCover.doWork = updateProject
                                busyCover.start()
                            } else {
                                showToast(qsTr("Offline"));
                            }
                        }
                     }
                }

                C.HorizontalDivider {}
            }

            ItemDelegate {
                Layout.fillWidth: true
                Layout.minimumHeight: C.Style.minRowHeight
                visible: !page.exportCsv

                contentItem: RowLayout {
                     width: parent.width
                     height: parent.height

                     ColumnLayout {
                         Layout.fillWidth: true

                         Label {
                             Layout.fillWidth: true
                             font.pixelSize: App.settings.font14
                             elide: Text.ElideRight
                             wrapMode: Label.WordWrap
                             text: form.project.loggedIn ? qsTr("Logged in as") : qsTr("Logged out")
                         }

                         Label {
                             Layout.fillWidth: true
                             color: Material.foreground
                             opacity: 0.5
                             font.pixelSize: App.settings.font12
                             elide: Text.ElideRight
                             text: form.project.username === "" ? "-" : form.project.username
                             wrapMode: Label.WordWrap
                         }
                     }

                     Button {
                         text: form.project.loggedIn ? qsTr("Logout") : qsTr("Login")
                         font.pixelSize: App.settings.font14
                         font.capitalization: Font.MixedCase
                         icon.source: form.project.loggedIn ? "qrc:/icons/logout.svg" : "qrc:/icons/login.svg"
                         Layout.alignment: Qt.AlignRight
                         onClicked: {
                             if (form.project.loggedIn) {
                                confirmLogout.open()
                             } else {
                                 form.triggerLogin()
                             }
                         }
                     }
                }

                C.HorizontalDivider {}
            }

            ItemDelegate {
                Layout.fillWidth: true
                Layout.minimumHeight: C.Style.minRowHeight
                visible: (page.custom.reportedByElement || "") !== ""

                contentItem: RowLayout {
                    width: parent.width
                    height: parent.height

                    ColumnLayout {
                        Layout.fillWidth: true

                        Label {
                            text: qsTr("Reported by")
                            font.pixelSize: App.settings.font14
                            elide: Text.ElideRight
                            Layout.fillWidth: true
                            wrapMode: Label.WordWrap
                        }

                        Label {
                            property string reportedBy: form.project.reportedBy
                            property bool reportedByValid: reportedBy !== ""
                            text: reportedByValid ? form.getElementName(reportedBy) : qsTr("Unknown")
                            color: reportedByValid ? Material.foreground : "red"
                            opacity: reportedByValid ? 0.5 : 1.0
                            font.italic: !reportedByValid
                            font.pixelSize: App.settings.font12
                            elide: Text.ElideRight
                            Layout.fillWidth: true
                        }
                    }

                    C.ChevronRight {}
                }

                onClicked: form.pushPage("qrc:/ReportedByPage.qml", { elementUid: page.custom.reportedByElement })

                C.HorizontalDivider {}
            }

            ItemDelegate {
                Layout.fillWidth: true
                Layout.minimumHeight: C.Style.minRowHeight
                visible: page.exportCsv

                contentItem: RowLayout {
                    ColumnLayout {
                        Layout.fillWidth: true

                        Label {
                            Layout.fillWidth: true
                            font.pixelSize: App.settings.font14
                            text: qsTr("Exported data")
                            elide: Text.ElideRight
                            wrapMode: Label.WordWrap
                        }

                        Label {
                            Layout.fillWidth: true
                            font.pixelSize: App.settings.font12
                            opacity: 0.5
                            text: qsTr("The CSV files exported so far, to share")
                            elide: Text.ElideRight
                            wrapMode: Label.WordWrap
                        }
                    }

                    C.ChevronRight {}
                }

                onClicked: form.pushPage("qrc:/ExportsPage.qml", { projectUid: form.project.uid })

                C.HorizontalDivider {}
            }

            C.FooterSpacer {}
        }
    }

    C.ConfirmPopup {
        id: confirmLogout
        text: qsTr("Logout?")
        onConfirmed: {
            form.project.logout()
            form.triggerLogin()
        }
    }

    function updateProject() {
        let result = App.projectManager.update(form.project.uid)
        if (result.success) {
            changeToProject(form.projectUid)
            return
        }
    }
}
